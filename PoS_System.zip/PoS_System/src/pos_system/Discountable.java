
package pos_system;

public interface Discountable {

   public double calculateDiscount(double discountRate);
}
